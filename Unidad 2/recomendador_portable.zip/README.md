# Recomendador de Platillos (demo)

Este repositorio contiene un recomendador básico (BN) y una GUI Tkinter.

Requisitos
- Python 3.10+ recomendado
- pip
- Windows PowerShell (instrucciones incluidas)

Pasos rápidos (Windows - PowerShell)

1. Crear entorno virtual e instalar dependencias:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

2. Ejecutar la interfaz gráfica:

```powershell
.\.venv\Scripts\python.exe interfaz.py
```

3. O ejecutar el CLI para ver recomendaciones:

```powershell
.\.venv\Scripts\python.exe main.py
```

Notas
- `tkinter` viene con Python en la mayoría de instalaciones en Windows.
- Si hay problemas con `pgmpy`, instala compiladores/bibliotecas necesarios (ver docs de pgmpy).
- Los datos principales están en `data/` (platos, disponibilidad, red semántica).

Archivos útiles
- `recomendador.py` — lógica BN
- `interfaz.py` — GUI (Tkinter)
- `main.py` — CLI

Si quieres, puedo añadir un `Dockerfile` o un instalador más completo (setup.ps1).