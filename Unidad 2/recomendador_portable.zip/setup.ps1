# Script de preparación (PowerShell) para Windows
# Crea un entorno virtual e instala dependencias del proyecto.

param(
    [string]$venvPath = ".venv"
)

Write-Host "Creando entorno virtual en $venvPath ..."
python -m venv $venvPath
Write-Host "Activando entorno virtual..."
& "$venvPath\Scripts\Activate.ps1"
Write-Host "Instalando dependencias..."
pip install --upgrade pip
pip install -r requirements.txt
Write-Host "Instalación completa. Para ejecutar la interfaz ahora:
.\$venvPath\Scripts\python.exe interfaz.py"